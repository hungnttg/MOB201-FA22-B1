package com.example.myapplication.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo11Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btnStart, btnStop;
    Intent intent1,intent2,intent3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo11_main2);
        intent1 = new Intent(this,MyService1.class);
        intent2  =new Intent(this,MyService2.class);
        intent3 = new Intent(this,MyService3.class);
        txt1 = findViewById(R.id.demo11Txt1);
        txt2 = findViewById(R.id.demo11Txt2);
        btnStart = findViewById(R.id.demo11BtnStart);
        btnStop = findViewById(R.id.demo11BtnStop);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startService(intent1);
//                //Lay du lieu nguoi dung nhap
//                String masv = txt1.getText().toString();
//                String tensv = txt2.getText().toString();
//                //dua du lieu vao intent
//                intent2.putExtra("masv",masv);
//                intent2.putExtra("tensv",tensv);
//                //goi service
//                startService(intent2);

                //Lay ky tu nguoi dung nhap
                String intputChar = txt1.getText().toString();
                char[] c = intputChar.toCharArray();//bien thanh mang ky tu

                String chuoiCanCheck = txt2.getText().toString();
                intent3.putExtra("char",c[0]);
                intent3.putExtra("chk",chuoiCanCheck);
                //goi service de xu ly
                startService(intent3);
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopService(intent3);
            }
        });
    }
}
