package com.example.myapplication.demo1;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService3 extends IntentService {
    public MyService3() {
        super("MyService3");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        char c1 = intent.getCharExtra("char",'0');
        String chuoiCanCheck = intent.getStringExtra("chk");
        count = demKyTu(chuoiCanCheck,c1);
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"So ky tu la: "+count,
                Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"Huy service tu dong",
                Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }
    int count = 0;
    //ham dem ky tu
    public int demKyTu(String str,char c)
    {
        int dem=0;
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)==c)
            {
                dem++;
            }
        }
        return dem;
    }
}
