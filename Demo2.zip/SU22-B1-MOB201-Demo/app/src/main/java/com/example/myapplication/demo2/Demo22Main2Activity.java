package com.example.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo22Main2Activity extends AppCompatActivity {
    Button button;
    EditText txt1;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        context = this;
        button = findViewById(R.id.demo22Btn1);
        txt1 = findViewById(R.id.demo22Txt1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //lay du lieu nguoi dung nhap
                String dulieu = txt1.getText().toString();
                //truyen du lieu cho intent
                Intent intent = new Intent(context,MyBroadcast2.class);
                intent.putExtra("br",dulieu);
                //yeu cau broadcast
                sendBroadcast(intent);
            }
        });
    }
}
