package com.example.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo23Main2Activity extends AppCompatActivity {
    Button button;
    EditText txt1;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main2);
        context = this;
        button = findViewById(R.id.demo23Btn1);
        txt1 = findViewById(R.id.demo23Txt1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dulieu = txt1.getText().toString();
                Intent intent = new Intent(context,MyBroadcast3.class);
                intent.putExtra("br",dulieu);
                sendBroadcast(intent);
            }
        });

    }
}
