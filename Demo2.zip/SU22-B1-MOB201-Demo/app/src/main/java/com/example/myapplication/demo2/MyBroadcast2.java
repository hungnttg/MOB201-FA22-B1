package com.example.myapplication.demo2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadcast2 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //nhan du lieu
        String sms = intent.getExtras().getString("br");
        //Phat lai thong diep
        Toast.makeText(context,sms,Toast.LENGTH_LONG).show();
    }
}
