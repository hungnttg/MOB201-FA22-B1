package com.example.myapplication.demo4n;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo4n2Main2Activity extends AppCompatActivity {
    TextView textView;
    ConnectivityManager connectivityManager;
    NetworkInfo myWifi, my4G;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo4n2_main2);
        textView = findViewById(R.id.demo4n2Tv1);
        //goi service
        connectivityManager=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        // xac dinh thong tin mang
        myWifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        my4G = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

        WifiManager wifimanager = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);

        String ip =
                android.text.format.Formatter.formatIpAddress(wifimanager.getConnectionInfo().getIpAddress());

        //kiem tra ket noi
        if(myWifi.isConnected())
        {
            textView.setText("Dang dung wifi, va ip la: "+ip);
        }
        else if(my4G.isConnected())
        {
            textView.setText("Dang dung 4G");
        }
    }
}
