package com.example.myapplication.demo5n;

//b1 - Tạo interface
public interface Demo5n1LangNghe {
    boolean layDuLieuThanhCong(boolean tc);
}
