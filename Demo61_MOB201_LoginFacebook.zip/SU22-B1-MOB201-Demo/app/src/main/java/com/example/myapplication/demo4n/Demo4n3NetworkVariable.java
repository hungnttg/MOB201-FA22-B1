package com.example.myapplication.demo4n;

public class Demo4n3NetworkVariable {
    public static boolean isNetworkConnected = false;//bien truyen khi callback
}
