package com.example.myapplication.demo5;
//I. Tao interface
public interface LangNgheComplete {
    boolean downloadComplete(boolean kq);
}
