package com.example.myapplication.demo5nn;

//B1 - ĐỊnh nghĩa interface (người điều tiết xúc cát)
public interface DieuTietInterface {
    boolean daXucCatXongChua(boolean xc);
}
